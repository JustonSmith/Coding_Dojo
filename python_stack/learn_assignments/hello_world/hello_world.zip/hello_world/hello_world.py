
# TASK 1: print "hello World"

print("Hello World")

# TASK 2: print "Hello Noelle!" with the name in a variable.

name = 'Noelle'
print("Hello", name) # with a comma
print("Hello" + name) # with a +

# TASK 3: print "Hello 42" with the number in the variable

num = "hello %d" % 42
print(num)

# TASK 4: print "I love sushi and pizza." with the foods in variables.

food_1 = 'sushi'
food_2 = 'pizza'
print("I love {} and {}.".format(food_1, food_2))
print(f" I love {food_1} and {food_2}.")