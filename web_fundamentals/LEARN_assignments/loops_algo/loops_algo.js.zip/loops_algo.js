// 
// 

//Loops Algo:

// Print odds 1-20:

for(var i = 1; i <= 20; i += 2){
    console.log(i)
}

// Sum and print 1-5:

function integerPrint(){
    var sum = 0
        for(var i = 1; i <= 5; i++){
            console.log(i)
            sum += i
            console.log(sum)
        }
    }
    integerPrint()