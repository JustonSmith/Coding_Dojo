// 
// 
// Loops Predict:

// Predict 1:

for(var num = 0; num<15; num++){
    console.log(num)
}

// The computer will log 0 - 15 into the console.

// Predict 2:

for(var i = 1; i < 1; i+=2){
    if(i % 3 == 0){
        console.log(i)
    }
}

// The computer will log any number that a multiple of three, until it reaches 10. The computer will also count up to 10 by two.

// Predict 3:

for(var j = 1; j <= 15; j++){
    if(j % 2 == 0){
        j += 2
    }
    else if(j % 3 == 0){
    }
    console.log(j)

}