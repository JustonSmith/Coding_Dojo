from django.apps import AppConfig


class OpenMicsAppConfig(AppConfig):
    name = 'open_mics_app'
