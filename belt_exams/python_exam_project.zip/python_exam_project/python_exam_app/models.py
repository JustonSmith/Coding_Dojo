from django.db import models
from django.contrib.auth.models import User
import re
email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')

# Create your models here.

class User_Manager(models.Manager):
    def registration_validator(self, form_data):
        errors = {}
        email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')
        if len(form_data['first_name']) < 2:
            errors['first_name'] = "First name must be at least 2 characters"
        if len(form_data['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        if not email_regex.match(form_data['registration_email']):
            errors['registration_email'] = "Invalid email address."
        if len(form_data['registration_password']) < 8:
            errors['registration_password'] = "Password must be at least 8 characters"
        if form_data['registration_password'] != form_data['confirm_password']:
            errors['confirm_password'] = "passwords must match."
        return errors

    def login_validator(self, form_data):
        errors = {}
        email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')
        if not email_regex.match(form_data['login_email']):
            errors['login_email'] = "Please enter a valid email address"
        if len(form_data['login_password']) == 0:
            errors['login_password'] = "Please enter password."
        return errors

class Job_Manager(models.Manager):
    def job_validator(self, form_data):
        errors = {}
        if len(form_data['title']) < 2:
            errors['venue'] = "title must be at least 2 characters."
        if len(form_data['location']) < 2:
            errors['location'] = "location must be at least 2 characters."
        if len(form_data['description']) < 10:
            errors['description'] = "Description should be at least 10 characters."
        return errors 

class Catergory_Manager(models.Manager):
    def category_validator(self, form_data):
        errors = {}
        if len(form_data['category']) < 3:
            errors['category'] = 'Category must have at least 3 characters.'
        return errors

class Category(models.Model):
    category = models.CharField(max_length = 255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)

class User(models.Model):
    first_name = models.CharField(max_length = 45)
    last_name = models.CharField(max_length = 45)
    email= models.CharField(max_length = 255)
    password = models.CharField(max_length = 255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = User_Manager()

class Job(models.Model):
    title = models.CharField(max_length = 45)
    location = models.CharField(max_length = 255)
    description = models.TextField()
    created_by_user = models.ForeignKey(User, related_name = 'created_jobs', on_delete = models.CASCADE)
    added_users = models.ManyToManyField(User, related_name = 'added_jobs')
    categories = models.ManyToManyField(Category, related_name = 'jobs')
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = Job_Manager()