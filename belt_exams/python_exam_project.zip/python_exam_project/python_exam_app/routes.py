from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login',views.login),
    path('logout', views.logout),
    path('dashboard', views.dashboard),
    path('jobs/add', views.add_job),
    path('jobs/create', views.create_job),
    path('jobs/<int:job_id>/edit', views.edit_job),
    path('jobs/<int:job_id>/update', views.update_job),
    path('jobs/<int:job_id>', views.view_job),
    path('jobs/<int:job_id>/delete', views.delete_job),
    path('jobs/<int:job_id>/add_to_user', views.add_job_to_user),
    path('jobs/<int:job_id>/remove_from_user', views.remove_job_from_user),
    path('jobs/<int:job_id>/finished', views.finished_job)
]