from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Job, Category
import re
import bcrypt
email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')

# Create your views here.

def index(request):
    return render(request, "index.html")

def register(request):
    errors = User.objects.registration_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            if key == 'first_name':
                messages.error(request, value,  extra_tags = 'first_name')
            if key == 'last_name':
                messages.error(request, value,  extra_tags = 'last_name')
            if key == 'registration_email':
                messages.error(request, value,  extra_tags = 'registration_email')
            if key == 'registration_password':
                messages.error(request, value,  extra_tags = 'registration_password')
            if key == 'confirm_password':
                messages.error(request, value,  extra_tags = 'confirm_password')
        return redirect('/')
    else:
        hashed_password = bcrypt.hashpw(request.POST['registration_password'].encode(), bcrypt.gensalt())
        user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['registration_email'],
            password = hashed_password
        )
        request.session['user_id'] = user.id
        return redirect('/dashboard')

def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            if key == 'login_email':
                messages.error(request, value, extra_tags = 'login_email')
            if key == 'login_password':
                messages.error(request, value, extra_tags = 'login_password')
        return redirect('/')
    else:
        user_list = User.objects.filter(email = request.POST['login_email'])
        if len(user_list) == 0:
            messages.error(request, 'Sorry, a user with that address was not found. Please use valid email, or register an account.', extra_tags = 'login_email')
            return redirect('/')
        else:
            user = user_list[0]
            if bcrypt.checkpw(request.POST['login_password']. encode(),user.password.encode()):
                request.session['user_id'] = user.id
                return redirect('/dashboard')
            else:
                messages.error(request, 'Sorry, the password you entered was incorrect. Please try again.', extra_tags = 'login_password')
                return redirect('/')

def logout(request):
    request.session.flush()
    return redirect('/')

def dashboard(request):
    current_user = User.objects.get(id = request.session['user_id'])
    current_user_added_jobs = current_user.added_jobs.all()
    all_jobs = Job.objects.exclude(id__in = current_user_added_jobs)
    context = {
        'current_user': current_user,
        'all_jobs': all_jobs,
        'users_added_jobs': current_user_added_jobs,
    }
    return render(request, 'dashboard.html', context)

def add_job(request):
    current_user = User.objects.get(id=request.session['user_id'])
    category_options = Category.objects.all().order_by('created_at')
    context = {
        'current_user': current_user,
        'category_options': category_options
    }
    return render(request, 'add_job.html', context)

def create_job(request):
    current_user = User.objects.get(id=request.session['user_id'])
    job_errors = Job.objects.job_validator(request.POST)
    if len(Category.objects.filter(category = request.POST['category_text'])) != 0:
        messages.error(request, "This category already exists. Please check category list and try again.")
        return redirect('/jobs/add')
    if len(job_errors) > 0:
        for key, val in job_errors.items():
            messages.error(request, val)
        return redirect('/jobs/add')
    new_job = Job.objects.create(
        title = request.POST['title'],
        location = request.POST['location'],
        description = request.POST['description'],
        created_by_user = current_user,
    )
    if request.POST['category_text'] != "":
        new_category = Category.objects.create(category = request.POST['category_text'])
        new_job.categories.add(new_category)
    if request.POST.getlist('category') != []:
        for category_id in request.POST.getlist('category'):
            category = Category.objects.get(id = category_id)
            category.jobs.add(new_job)

    return redirect('/dashboard')

def edit_job(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    all_categories = Category.objects.all()
    if current_job.created_by_user != current_user:
        messages.error(request, "This job has not been created.")
        return redirect('/dashboard')
    context = {
        "current_user": current_user,
        "current_job": current_job,
        "all_categories": all_categories,
    }
    return render(request, 'edit_job.html', context)

def update_job(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    if len(Category.objects.filter(category = request.POST['category_text'])) != 0:
        messages.error(request, "This category already exists. Please check category list and try again.")
        return redirect(f'/jobs/{job_id}/edit')
    if current_job.created_by_user != current_user:
        messages.error(request, "This job has not been created.")
        return redirect('/dashboard')
    job_errors = Job.objects.job_validator(request.POST)
    if len(job_errors) > 0:
        for key, val in job_errors.items():
            messages.error(request, value)
        return redirect(f'/jobs/{job_id}/edit')
    for category in Category.objects.exclude(id__in = request.POST.getlist('category')):
        current_job.categories.remove(category)
    if request.POST['category_text'] != "":
        new_category = Category.objects.create(category = request.POST['category_text'])
        current_job.categories.add(new_category)
    for category_id in request.POST.getlist('category'):
        category = Category.objects.get(id = category_id)
        category.jobs.add(current_job)
    current_job.title = request.POST['title']
    current_job.location = request.POST['location']
    current_job.description = request.POST['description']
    current_job.save()
    return redirect('/dashboard')

def view_job(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    all_categories = Category.objects.all().order_by('category')
    current_user_added_jobs = current_user.added_jobs.all()
    all_jobs = Job.objects.exclude(id__in=current_user_added_jobs)
    category_empty = True
    if len(current_job.categories.all()) != 0:
        category_empty = False
    context = {
        'current_user': current_user,
        'all_jobs': all_jobs,
        'current_user_added_jobs': current_user_added_jobs,
        'current_job': current_job,
        'all_categories': all_categories,
        'category_empty': category_empty
    }
    return render(request, 'view_job.html', context)

def delete_job(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    if current_job.created_by_user != current_user:
        messages.error(request, "This job has not been created.")
        return redirect('/dashboard')
    current_job.delete()
    return redirect('/dashboard')

def add_job_to_user(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    current_user.added_jobs.add(current_job)
    return redirect('/dashboard')

def remove_job_from_user(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    current_user.added_jobs.remove(current_job)
    return redirect('/dashboard')

def finished_job(request, job_id):
    current_user = User.objects.get(id=request.session['user_id'])
    current_job = Job.objects.get(id = job_id)
    if current_user not in current_job.added_users.all():
        messages.error(request, "This job has not been added.")
        return redirect('/dashboard')
    current_job.delete()
    return redirect('/dashboard')





