from django.db import models
from django.contrib.auth.models import User
import re
import bcrypt

email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')



# # # # # # # # # # # # # # # # # 
# #-----QUOTES_APP_MODELS-----# #
# # # # # # # # # # # # # # # # #



#_____LOGIN/REGISTRATION_VALIDATION_____#


class User_Manager(models.Manager):
    def registration_validator(self, form_data):
        errors = {}
        email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')
        if len(form_data['first_name']) < 2:
            errors['first_name'] = "First name must be at least 2 characters"
        if len(form_data['last_name']) < 2:
            errors['last_name'] = "Last name must be at least 2 characters"
        if not email_regex.match(form_data['registration_email']):
            errors['registration_email'] = "Invalid email address."
        if len(form_data['registration_password']) < 8:
            errors['registration_password'] = "Password must be at least 8 characters"
        if form_data['registration_password'] != form_data['confirm_password']:
            errors['confirm_password'] = "passwords must match."
        return errors

    def login_validator(self, form_data):
        errors = {}
        email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')
        if not email_regex.match(form_data['login_email']):
            errors['login_email'] = "Please enter a valid email address"
        if len(form_data['login_password']) == 0:
            errors['login_password'] = "Please enter password."
        return errors


#_____QUOTE_VALIDATION_____#


class Quote_Manager(models.Manager):
    def quote_validator(self, form_data):
        errors = {}
        if len(form_data['posted_by']) < 4:
            errors['posted_by'] = "cannot be less than 4 characters."
        if len(form_data['quote_text']) > 10:
            errors['quote_text'] = "cannot be less than 10 characters."
        return errors

        current_user = User.objects.get(id = user_id)
        self.create(quote_text = quote_text, posted_by = current_user, quoted_by = quoted_by)
        errors = "created quote."
        return errors


#_____LIKES_____#

# class Likes(models.Model):
#     likes = models.ManyToManyField(User, related_name = 'likes')

#     def number_of_likes(self):
#         return self.likes.count()

    def add_user_likes(self, user_id, quote_id):
        quote = Quote.objects.get(id = quote_id)
        current_user = USER.objects.get(id = user_id)
        quote.user_likes.add(current_user)
        return self.likes.count()


    def remove_user_likes(self, user_id, quote_id):
        quote = Quote.objects.get(id = quote_id)
        current_user = User.objects.get(id = quote_id)
        quote.user_.likes.remove(current_user)
        return self.likes.count()


#_____USER_____#


class User(models.Model):
    first_name = models.CharField(max_length = 45)
    last_name = models.CharField(max_length = 45)
    email= models.CharField(max_length = 255)
    password = models.CharField(max_length = 255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = User_Manager()


#______QUOTES______#


class Quote(models.Model):
    quote_text = models.TextField()
    posted_by = models.ForeignKey(User, related_name = 'posted_by', on_delete = models.CASCADE)
    quoted_by = models.CharField(max_length = 255)
    created_at = models.DateTimeField(auto_now_add = True)
    user_likes = models.ManyToManyField(User, related_name = 'user_likes')
    updated_at = models.DateTimeField(auto_now = True)
    objects = Quote_Manager()