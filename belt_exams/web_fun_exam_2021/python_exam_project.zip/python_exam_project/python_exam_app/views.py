from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib import messages
from .models import *
import re
# import bcrypt
# email_regex = re.compile(r'^[a-zA-Z0-9.+-]+@[a-zA-Z0-9._-]+\.[a-zA-z]+$')
# password_regex = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$')


# # # # # # # # # # # # # # # # #
# #-----QUOTES_APP_VIEWS-----#  # 
# # # # # # # # # # # # # # # # #


#_____HOME_____#


def index(request):
    return render(request, "index.html")


#_____REGISTER_____#


def register(request):
    errors = User.objects.registration_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            if key == 'first_name':
                messages.error(request, value,  extra_tags = 'first_name')
            if key == 'last_name':
                messages.error(request, value,  extra_tags = 'last_name')
            if key == 'registration_email':
                messages.error(request, value,  extra_tags = 'registration_email')
            if key == 'registration_password':
                messages.error(request, value,  extra_tags = 'registration_password')
            if key == 'confirm_password':
                messages.error(request, value,  extra_tags = 'confirm_password')
        return redirect('/')
    else:
        hashed_password = bcrypt.hashpw(request.POST['registration_password'].encode(), bcrypt.gensalt())
        new_user = User.objects.create(
            first_name = request.POST['first_name'],
            last_name = request.POST['last_name'],
            email = request.POST['registration_email'],
            password = hashed_password
        )
        request.session['user_id'] = new_user.id
        return redirect('/all_quotes')


#_____LOGIN_____#


def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            if key == 'login_email':
                messages.error(request, value, extra_tags = 'login_email')
            if key == 'login_password':
                messages.error(request, value, extra_tags = 'login_password')
        return redirect('/')
    else:
        user_list = User.objects.filter(email = request.POST['login_email'])
        if len(user_list) == 0:
            messages.error(request, 'Sorry, a user with that address whas not found. Please use valid email, or register an account.')
            return redirect('/')
        else:
            user = user_list[0]
            if bcrypt.checkpw(
                request.POST['login_password']. encode(),
                user.password.encode()
            ):
                request.session['user_id'] = user.id
                messages.error(request, 'Sorry, the password you entered was incorrect. Please try again.')
            return redirect('/quotes')


#____LOGOUT_____#


def logout():
    request.session.flush()
    return redirect('/')


#_____USERS_____#


def users(request):
    posted_by = User.object.get(id = user_id)
    context = {
        'quotes': Quote.objects.filter(posted_by = posted_by)
    }


#_____SEE_ALL_QUOTES_____#


def all_quotes(request):
    all_users = User.objects.all()
    current_user = User.objects.get(id = request.session['user_id'])
    user_likes = Quote.objects.filter(user_likes = current_user)
    all_quotes = Quote.objects.all().order_by('user_id')
    context = {
        'all_users': all_users,
        'current_user': current_user,
        'quotes': all_quotes,
        'user_likes': user_likes,
    }
    return render(request, 'quotes.html', context)


#_____POST_QUOTE_____#


def post_quote():
    errors = User.objects.quote_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            if key == 'quote_text':
                messages.error(request, value, extra_tags = 'quote_text')
            return redirect('/quotes')
        else:
            user_id = request.session['user_id']
            post_quote = Quote.objects.create(
                posted_by = request.POST['posted_by'],
                quote_text = request.POST['quote_text'],
                quoting_user = User.objects.get(id = request.session['user_id']))
            return redirect('/quotes')


#_____DELETE_QUOTE_____#


def delete_quote():
    quote_killer = Wish.objects.get(
        id = request.POST['quote_text'])
    quote_killer.delete()
    return redirect('/quotes')


#_____ADD_LIKES_____#


# def quote_likes(request, pk):
#     quote = get_object_or_404(Likes, id = request.POST.get('likes_id'))
#     if post.likes.filter(id = request.user.id). exists():
#         post.likes.remove(request.user)
#     else:
#         post.likes.add(request.user)

#     return HttpResponseRedirect(reverse('likes-detail', args = [str(pk)]))

# class quote_likes_detail_view

def add_likes_current_user():
    user_id = request.session['user_id']
    Quote.objects.add_user_likes(user_id, quote_id)
    return redirect('/quotes')

def remove_likes_current_user():
    user_id = request.session['user_id']
    Quote.object.remove_user_likes(user_id, quote_id)
    return redirect('/quotes')








