from django.apps import AppConfig


class PythonExamAppConfig(AppConfig):
    name = 'python_exam_app'
