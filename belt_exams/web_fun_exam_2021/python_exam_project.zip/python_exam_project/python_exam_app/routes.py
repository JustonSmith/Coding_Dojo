from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('logout', views.logout),
    path('users', views.users),
    path('all_quotes', views.all_quotes),
    path('post_quote', views.post_quote),
    path('delete_quote', views.delete_quote),
    path('add_likes_current_user', views.add_likes_current_user),
    path('remove_likes_current_user', views.remove_likes_current_user),
]