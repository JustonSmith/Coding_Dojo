module ObjectMaster1 {
}