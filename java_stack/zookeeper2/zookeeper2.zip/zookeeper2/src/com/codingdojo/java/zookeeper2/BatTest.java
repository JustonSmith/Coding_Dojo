package com.codingdojo.java.zookeeper2;

public class BatTest {
	public static void main(String[] args) {
		
		Bat woosh = new Bat();
		woosh.attackTown();
		woosh.attackTown();
		woosh.attackTown();
		woosh.eatHumans();
		woosh.eatHumans();
		woosh.fly();
		woosh.fly();
	}
}
