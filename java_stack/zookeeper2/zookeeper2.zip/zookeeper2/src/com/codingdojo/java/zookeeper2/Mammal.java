package com.codingdojo.java.zookeeper2;

public class Mammal {

}
