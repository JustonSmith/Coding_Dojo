module ObjectMaster2 {
}