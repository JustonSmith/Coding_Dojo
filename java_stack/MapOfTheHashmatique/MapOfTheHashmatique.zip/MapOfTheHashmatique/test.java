public class Test{
    public static void main(String[] args){
    MapOfTheHashmatique bandInfo = new MapOfTheHashmatique();

    bandInfo.retriveSongData();
    }
}
}
