/**
 * 
 */
 
 $(document).ready(function(){
	alert("This is the date template!");
});