/**
 * 
 */
 
 $(document).ready(function(){
	alert("This is the time template!");
});