package com.codingdojo.java_stack.counter.controllers;

public class ResetController {

}
