package java_stack.ProjectClass;

public class ProjectClassTest {
    public static void main(String[] args) {
        ProjectClass testProject = new ProjectClass("Break ground on new pool", "In my backyard with a waterfall cave and diving board.", 150,000.00);
        testProject.setName ("Move into the country");
        testProject.setDescription("Move into a barndominium on a few acres with a lift for the chopper and racecar.");
        testProject.setCost(1,000,000.00);
        System.out.println(testProject.getName());
        System.out.println(testProject.getDescription());
        System.out.println(testProject.getCost());
        System.out.println(testProject.ElevatorPitch());
    }
}
