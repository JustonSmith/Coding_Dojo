package com.codingdojo.java.FizzBuzz;

public class FizzBuzzTest {
	public static void main(String[] args) {
		FizzBuzz bubbles = new FizzBuzz();
		String result = bubbles.fizzBuzz(2);
		System.out.println(result);
	}

}
