
public class HelloWorld {
	public String greet() {
		return "Hello World!";
	}
}
