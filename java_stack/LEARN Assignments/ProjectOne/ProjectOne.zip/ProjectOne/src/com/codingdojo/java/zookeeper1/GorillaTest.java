package com.codingdojo.java.zookeeper1;

public class GorillaTest {
	public static void main(String[] args) {
		
		Gorilla testMonkey = new Gorilla();
		testMonkey.throwSomething();
		testMonkey.throwSomething();
		testMonkey.throwSomething();
		testMonkey.eatBananas();
		testMonkey.eatBananas();
		testMonkey.climb();
	}
}
