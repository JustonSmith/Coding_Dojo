
public class HelloWorldTest {
	public static void main(String[] args) {
		HelloWorld h = new HelloWorld();
		h.greet()
	}
}
