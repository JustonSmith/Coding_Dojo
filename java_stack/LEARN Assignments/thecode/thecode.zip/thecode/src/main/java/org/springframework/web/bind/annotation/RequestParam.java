package org.springframework.web.bind.annotation;

public class RequestParam {

}
