package com.codingdojo.java_stack.thecode.controllers;

public class SuccessControl {

}
