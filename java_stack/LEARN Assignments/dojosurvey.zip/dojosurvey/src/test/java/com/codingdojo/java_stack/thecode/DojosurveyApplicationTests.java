package com.codingdojo.java_stack.thecode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
