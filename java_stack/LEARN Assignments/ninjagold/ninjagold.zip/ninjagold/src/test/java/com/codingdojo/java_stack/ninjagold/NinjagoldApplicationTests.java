package com.codingdojo.java_stack.ninjagold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjagoldApplicationTests {

	@Test
	void contextLoads() {
	}

}
