import React from 'react'
import './App.css';
import toDo from './components/toDo';

function App() {
  return (
    <div className="App">
      <toDo/>
    </div>
  );
}

export default App;
