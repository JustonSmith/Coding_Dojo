package com.codingdojo.greatIdeasExam.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.greatIdeasExam.models.Idea;
import com.codingdojo.greatIdeasExam.repositories.IdeaRepository;

@Service
public class IdeaService {
	
	@Autowired
	private IdeaRepository ideaRepo;
	
	public List<Idea> createIdea(Idea ideas) {
		return (List<Idea>)this.ideaRepo.save(ideas);
	}
	
	public List<Idea> findallIdeas() {
		return (List<Idea>)this.ideaRepo.findAll();
	}
	
	public Idea findIdeaId(Long id) {
		return this.ideaRepo.findById(id).orElse(null);
	}
	
	
	
	
	
}
