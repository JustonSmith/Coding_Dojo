package com.codingdojo.greatIdeasExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreatIdeasExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreatIdeasExamApplication.class, args);
	}

}
