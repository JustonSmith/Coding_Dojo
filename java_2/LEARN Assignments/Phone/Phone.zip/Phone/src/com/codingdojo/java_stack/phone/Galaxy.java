package com.codingdojo.java_stack.phone;

public class Galaxy {

}
