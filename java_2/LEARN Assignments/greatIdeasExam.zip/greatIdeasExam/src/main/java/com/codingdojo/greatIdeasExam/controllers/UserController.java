package com.codingdojo.greatIdeasExam.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.greatIdeasExam.models.Idea;
import com.codingdojo.greatIdeasExam.models.User;
import com.codingdojo.greatIdeasExam.repositories.IdeaRepository;
import com.codingdojo.greatIdeasExam.services.IdeaService;
import com.codingdojo.greatIdeasExam.services.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userServ;
	
	@Autowired
	private IdeaService ideaServ;
	
	@Autowired
	private IdeaRepository ideaRepo;
	
	@GetMapping("/")
	public String home (@ModelAttribute("newUser") User newUser, @ModelAttribute ("user_log") User user) {
		return "loginReg.jsp";
	}
	
	@PostMapping("/registration")
	public String registerUser(@Valid @ModelAttribute("newUser") User newUser, BindingResult result, HttpSession session) {
		if (result.hasErrors()) {
			return "loginReg.jsp";
	
		} else {
			User u = userServ.registerUser(newUser);
			session.setAttribute("userId", u.getId());
			return "redirect:/ideas";
		}
	}
		
		
	@PostMapping("/login")
	public String loginUser(@ModelAttribute("newUser") User newUser, BindingResult result, String email, String password, HttpSession session, Model model) {
		
		if(userServ.authUser(email, password) == true) {
			User u = userServ.findByEmail(email);
			session.setAttribute("userId", u.getId());
			return "redirect:/ideas";
		} else {
			model.addAttribute("error", "Ivalid email or password. Try again.");
			return "loginReg.jsp";
		}
	}
	
	@GetMapping("/ideas")
	public String home (Model model, HttpSession session) {
		List<Idea> j = ideaServ.findallIdeas();
		model.addAttribute("ideas", j);
		User u = userServ.findUserById((Long) session.getAttribute("userId"));
		model.addAttribute("newUser", u);
		return "index.jsp";
	}
	
	@GetMapping("/ideas/new")
	public String createIdea(@ModelAttribute("ideas") Idea ideas) {
		return "newIdea.jsp";
	}
	
	
	@PostMapping ("/ideas/new")
	public String createIdeaPost (@Valid @ModelAttribute("ideas") Idea ideas, BindingResult result, HttpSession session) {
		if (result.hasErrors()) {
			return "newIdea.jsp";
			
		} else {
			User u = userServ.findUserById((Long) session.getAttribute("userId"));
			ideas.setCreator(u);
			Idea j = ideaRepo.save(ideas);
			return "redirect:/ideas";
		}
	}
	
	@GetMapping("ideas/show/{id}")
	public String showId(@PathVariable("id") Long id, Model model) {
		Idea j = ideaServ.findIdeaId(id);
		model.addAttribute("ideas", j);
		
		return "showIdea.jsp";
	}
	
//	@GetMapping("/ideas/edit/{id}")
//	public String edit(@PathVariable("id") Long id, Model model) {
//		Idea j = ideaServ.findIdeaId(id);
//		model.addAttribute("idea", j);
//		return "editIdea.jsp";
//	}
	

	
	@GetMapping("ideas/edit/{id}")
	public String trueEdit(@PathVariable("id") Long id, @Valid @ModelAttribute("ideas") Idea ideas, BindingResult result) {
		
		if(result.hasErrors()) {
			return "editIdea.jsp";
		} else {
			Idea j = ideaServ.findIdeaId(id);
			ideas.setCreator(j.getCreator());
			ideas.setLikers(j.getLikers());
			ideaRepo.save(ideas);
			return "redirect:/ideas";
		}
	}
	
	@GetMapping("/like/{id}")
	public String like (@PathVariable("id") Long id, HttpSession session) {
		User u = userServ.findUserById((Long) session.getAttribute("userId"));
		Idea j = ideaServ.findIdeaId(id);
		j.getLikers().add(u);
		ideaRepo.save(j);
		return "redirect:/ideas";
		}
	
	@GetMapping("/unlike/{id}")
	public String unlike(@PathVariable("id") Long id, HttpSession session) {
		User u = userServ.findUserById((Long) session.getAttribute("userId"));
		Idea j = ideaServ.findIdeaId(id);
		for (int i = 0; i < j.getLikers().size(); i++) {
			if (u.getId() == j.getLikers().get(i).getId()) {
				j.getLikers().remove(i);
				break;
			}
		}
		ideaRepo.save(j);
		return "redirect:/ideas";
		
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		ideaRepo.deleteById(id);
		return "redirect:/ideas";
	}
	
	

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

}

		


	
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	

