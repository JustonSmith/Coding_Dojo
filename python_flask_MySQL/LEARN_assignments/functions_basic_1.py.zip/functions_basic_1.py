#1
def number_of_food_groups():
    return 5
print(number_of_food_groups())

# The terminal will return 5.

#2

# There is an undefined variable so the function will not run. 

#3
def number_of_books_on_hold():
    return 5
    return 10
print(number_of_books_on_hold())

#  The terminal will return 5.

#4
def number_of_fingers():
    return 5
    print(10)
print(number_of_fingers())

# The terminal will again return 5.

#5
def number_of_great_lakes():
    print(5)
x = number_of_great_lakes()
print(x)

# The terminal will return 5 and none.

#6
def add(b,c):
    print(b+c)
print(add(1,2) + add(2,3))

# The terminal will return 3 and 5

#7
def concatenate(b,c):
    return str(b)+str(c)
print(concatenate(2,5))

# The terminal will return 25.

#8
def number_of_oceans_or_fingers_or_continents():
    b = 100
    print(b)
    if b < 10:
        return 5
    elif:
        return 10
    return 7
print(number_of_oceans_or_fingers_or_continents())

# The terminal will return 10, 7.

#9
def number_of_days_in_a_week_silicon_or_triangle_sides(b,c):
    if b<c:
        return 7
    else:
        return 14
    return 3
print(number_of_days_in_a_week_silicon_or_triangle_sides(2,3))
print(number_of_days_in_a_week_silicon_or_triangle_sides(5,3))
print(number_of_days_in_a_week_silicon_or_triangle_sides(2,3) + number_of_days_in_a_week_silicon_or_triangle_sides(5,3))

# The terminal will print 7, 14, and 21.

#10
def addition(b,c):
    return b+c
    return 10
print(addition(3,5))

# The terminal will print 8.








