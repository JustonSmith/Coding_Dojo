function greeting(){
    return "Hello World"
}
var word = greeting()
    console.log(word)
    
